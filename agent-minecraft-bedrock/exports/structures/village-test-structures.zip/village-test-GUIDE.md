# Guide Structure — Village Test

Généré le : 2026-06-21 20:37

## Brief

village médiéval avec spawn, maisons, marché et donjon

## Origine

`0 70 0`

## Fichiers `.mcfunction`

- `village-test.mcfunction`
- `village-test_spawn.mcfunction`
- `village-test_market.mcfunction`
- `village-test_dungeon.mcfunction`
- `village-test_houses.mcfunction`

## Import dans Bedrock

1. Copie les fichiers `.mcfunction` dans le behavior pack :
   `behavior_pack/functions/`
2. Réexporte le `.mcaddon` avec :

```bash
python3 mcaddon_export_agent.py --regenerate-uuids
```

3. Dans Minecraft Bedrock, active le behavior pack.
4. Lance :

```mcfunction
/function village-test
```

Tu peux aussi lancer les modules séparés :

```mcfunction
/function village-test_spawn
/function village-test_market
/function village-test_houses
/function village-test_dungeon
```

## Attention

Les commandes utilisent `/fill` et `/setblock`. Teste d'abord dans une copie du monde.

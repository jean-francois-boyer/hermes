# Guide Structure — Donjon Test

Généré le : 2026-06-21 20:37

## Brief

donjon sombre avec boss, pièges et coffre récompense

## Origine

`0 70 0`

## Fichiers `.mcfunction`

- `donjon-test.mcfunction`
- `donjon-test_spawn.mcfunction`
- `donjon-test_market.mcfunction`
- `donjon-test_dungeon.mcfunction`
- `donjon-test_houses.mcfunction`

## Import dans Bedrock

1. Copie les fichiers `.mcfunction` dans le behavior pack :
   `behavior_pack/functions/`
2. Réexporte le `.mcaddon` avec :

```bash
python3 mcaddon_export_agent.py --regenerate-uuids
```

3. Dans Minecraft Bedrock, active le behavior pack.
4. Lance :

```mcfunction
/function donjon-test
```

Tu peux aussi lancer les modules séparés :

```mcfunction
/function donjon-test_spawn
/function donjon-test_market
/function donjon-test_houses
/function donjon-test_dungeon
```

## Attention

Les commandes utilisent `/fill` et `/setblock`. Teste d'abord dans une copie du monde.

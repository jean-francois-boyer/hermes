Monde préparé par mcworld_export_agent.py
Après import dans Minecraft Bedrock, vérifier que les packs sont actifs.
Commandes de test : /function start puis /function quests
